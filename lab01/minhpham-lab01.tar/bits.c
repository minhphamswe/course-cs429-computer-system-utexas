/* 
 * CS:APP Data Lab 
 * 
 * <Please put your name and userid here>
 * 
 * bits.c - Source file with your solutions to the Lab.
 *          This is the file you will hand in to your instructor.
 *
 * WARNING: Do not include the <stdio.h> header; it confuses the dlc
 * compiler. You can still use printf for debugging without including
 * <stdio.h>, although you might get a compiler warning. In general,
 * it's not good practice to ignore compiler warnings, but in this
 * case it's OK.  
 */

#if 0
/*
 * Instructions to Students:
 *
 * STEP 1: Read the following instructions carefully.
 */

You will provide your solution to the Data Lab by
editing the collection of functions in this source file.

INTEGER CODING RULES:
 
  Replace the "return" statement in each function with one
  or more lines of C code that implements the function. Your code 
  must conform to the following style:
 
  int Funct(arg1, arg2, ...) {
      /* brief description of how your implementation works */
      int var1 = Expr1;
      ...
      int varM = ExprM;

      varJ = ExprJ;
      ...
      varN = ExprN;
      return ExprR;
  }

  Each "Expr" is an expression using ONLY the following:
  1. Integer constants 0 through 255 (0xFF), inclusive. You are
      not allowed to use big constants such as 0xffffffff.
  2. Function arguments and local variables (no global variables).
  3. Unary integer operations ! ~
  4. Binary integer operations & ^ | + << >>
    
  Some of the problems restrict the set of allowed operators even further.
  Each "Expr" may consist of multiple operators. You are not restricted to
  one operator per line.

  You are expressly forbidden to:
  1. Use any control constructs such as if, do, while, for, switch, etc.
  2. Define or use any macros.
  3. Define any additional functions in this file.
  4. Call any functions.
  5. Use any other operations, such as &&, ||, -, or ?:
  6. Use any form of casting.
  7. Use any data type other than int.  This implies that you
     cannot use arrays, structs, or unions.

 
  You may assume that your machine:
  1. Uses 2s complement, 32-bit representations of integers.
  2. Performs right shifts arithmetically.
  3. Has unpredictable behavior when shifting an integer by more
     than the word size.

EXAMPLES OF ACCEPTABLE CODING STYLE:
  /*
   * pow2plus1 - returns 2^x + 1, where 0 <= x <= 31
   */
  int pow2plus1(int x) {
     /* exploit ability of shifts to compute powers of 2 */
     return (1 << x) + 1;
  }

  /*
   * pow2plus4 - returns 2^x + 4, where 0 <= x <= 31
   */
  int pow2plus4(int x) {
     /* exploit ability of shifts to compute powers of 2 */
     int result = (1 << x);
     result += 4;
     return result;
  }

FLOATING POINT CODING RULES

For the problems that require you to implent floating-point operations,
the coding rules are less strict.  You are allowed to use looping and
conditional control.  You are allowed to use both ints and unsigneds.
You can use arbitrary integer and unsigned constants.

You are expressly forbidden to:
  1. Define or use any macros.
  2. Define any additional functions in this file.
  3. Call any functions.
  4. Use any form of casting.
  5. Use any data type other than int or unsigned.  This means that you
     cannot use arrays, structs, or unions.
  6. Use any floating point data types, operations, or constants.


NOTES:
  1. Use the dlc (data lab checker) compiler (described in the handout) to 
     check the legality of your solutions.
  2. Each function has a maximum number of operators (! ~ & ^ | + << >>)
     that you are allowed to use for your implementation of the function. 
     The max operator count is checked by dlc. Note that '=' is not 
     counted; you may use as many of these as you want without penalty.
  3. Use the btest test harness to check your functions for correctness.
  4. Use the BDD checker to formally verify your functions
  5. The maximum number of ops for each function is given in the
     header comment for each function. If there are any inconsistencies 
     between the maximum ops in the writeup and in this file, consider
     this file the authoritative source.

/*
 * STEP 2: Modify the following functions according the coding rules.
 * 
 *   IMPORTANT. TO AVOID GRADING SURPRISES:
 *   1. Use the dlc compiler to check that your solutions conform
 *      to the coding rules.
 *   2. Use the BDD checker to formally verify that your solutions produce 
 *      the correct answers.
 */


#endif
/* 
 * bitXor - x^y using only ~ and & 
 *   Example: bitXor(4, 5) = 1
 *   Legal ops: ~ &
 *   Max ops: 14
 *   Rating: 1
 */
int bitXor(int x, int y) {
  return (~(x & y) & ~(~x & ~y));
}
/* 
 * byteSwap - swaps the nth byte and the mth byte
 *  Examples: byteSwap(0x12345678, 1, 3) = 0x56341278
 *            byteSwap(0xDEADBEEF, 0, 2) = 0xDEEFBEAD
 *  You may assume that 0 <= n <= 3, 0 <= m <= 3
 *  Legal ops: ! ~ & ^ | + << >>
 *  Max ops: 25
 *  Rating: 2
 */
int byteSwap(int x, int n, int m) {
  int nx8 = n << 3;
  int mx8 = m << 3;
  int y = ((x >> nx8) ^ (x >> mx8)) & 0xff;
  y = (y << mx8) | (y << nx8);
  return x ^ y;
}
/* 
 * reverseBytes - reverse the bytes of x
 *   Example: reverseBytes(0x01020304) = 0x04030201
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 25
 *   Rating: 3
 */
int reverseBytes(int x) {
  int x1 = ((x >> 24) ^ x) & 0xff;
  int x2 = ((x >> 16) ^ (x >> 8)) & 0xff;
  int y = (x1 << 24) | x1 | (x2 << 16) | (x2 << 8);
  return x ^ y;
}
/* 
 * conditional - same as x ? y : z 
 *   Example: conditional(2,4,5) = 4
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 16
 *   Rating: 3
 */
int conditional(int x, int y, int z) {
  int mask = (!!x) << 31 >> 31;
  return ((mask & y) | (~mask & z));
}
/* 
 * minusOne - return a value of -1 
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 2
 *   Rating: 1
 */
int minusOne(void) {
  return ~0;
}
/*
 * isTmax - returns 1 if x is the maximum, two's complement number,
 *     and 0 otherwise 
 *   Legal ops: ! ~ & ^ | +
 *   Max ops: 10
 *   Rating: 1
 */
int isTmax(int x) {
  // x is TMAX if x+1 = TMIN (note TMAX = ~TMIN)
  // 0xffffffff also has this property, but its increment is 0
  int y = x + 1;
  return (!(~x ^ y)) & (!!y);
}
/* 
 * isNegative - return 1 if x < 0, return 0 otherwise 
 *   Example: isNegative(-1) = 1.
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 6
 *   Rating: 2
 */
int isNegative(int x) {
  return !!(x & (0x1 << 31));
}
/* 
 * negate - return -x 
 *   Example: negate(1) = -1.
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 5
 *   Rating: 2
 */
int negate(int x) {
  return ~x + 1;
}
/* 
 * subOK - Determine if can compute x-y without overflow
 *   Example: subOK(0x80000000,0x80000000) = 1,
 *            subOK(0x80000000,0x70000000) = 0, 
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 20
 *   Rating: 3
 */
int subOK(int x, int y) {
  int sign_mask = (1 << 31);
  
  int sign_x = x & sign_mask;
  int sign_neg_y = (y & sign_mask) ^ sign_mask;  // sign of -y
  
  int diff = x + ~y + 1;
  int sign_diff = diff & sign_mask;
  // overflow if x and -y is of the same sign,
  // and the difference is of a different sign
  int fail = !(sign_x ^ sign_neg_y) & !!(sign_x ^ sign_diff);
  return !fail;
}
/* 
 * rempwr2 - Compute x%(2^n), for 0 <= n <= 30
 *   Negative arguments should yield negative remainders
 *   Examples: rempwr2(15,2) = 3, rempwr2(-35,3) = -3
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 20
 *   Rating: 3
 */
int rempwr2(int x, int n) {
  int neg_mask = (x & (1 << 31)) >> 31;
  // if x positive, drop last n digits
  // if x negative, negate x, apply procedure above, then negate the result
  int y = (~neg_mask & x) | (neg_mask & (~x + 1));
  int r = y & ((1 << n) + ~0);
  r = (~neg_mask & r) | (neg_mask & (~r + 1));
  return r;
}
/* 
 * isLessOrEqual - if x <= y  then return 1, else return 0 
 *   Example: isLessOrEqual(4,5) = 1.
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 24
 *   Rating: 3
 */
int isLessOrEqual(int x, int y) {
  // NOTE 1 (OLD):
  // Note: x > y if the rightmost w-1 bits of x is greater than those of y
  // (1 > 0) in all cases except when x * y < 0, in which case whichever number
  // has 1 for a sign bit is smaller (1 < 0).
  // If we flip the sign bits of both x and y, the problem becomes comparing
  // bits uniformly: whichever has a 1 first is greater.
  // In other words, we changed the number line from:
  // <<<<<<<<<<<<<<<<<<<<<<<<<<<<< T_MAX |  T_MIN <<<<<<<<<<<<<<<<<<<<<<<<<<<<<
  // to:
  // T_MAX >>>>>>>>>>>>>>>>>>>>>>>>>>>>> | >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> T_MIN
  
  // NOTE 2 (CURRENT):
  // shift x and y to right 1 place to avoid overflow, execute a subtraction
  // if result is 0, compare the rightmost bits
  
  int sign = (1 << 31);
  int leq1 = !(x ^ y);    // x = y
  int x1 = x >> 1;
  int y1 = y >> 1;
  int diff = x1 + ~y1 + 1;
  int leq2 = !!(diff & sign);   // x/2 - y/2 < 0

  int cLSB = !!(((x & 1) + ~(y & 1) + 1) & sign);
  // (x/2 - y/2 == 0) && (x%2 - y%2 < 0)
  int leq3 = (!diff) & cLSB;

  return leq1 | leq2 | leq3;
}
/*
 * ezThreeFourths - multiplies by 3/4 rounding toward 0,
 *   Should exactly duplicate effect of C expression (x*3/4),
 *   including overflow behavior.
 *   Examples: ezThreeFourths(11) = 8
 *             ezThreeFourths(-9) = -6
 *             ezThreeFourths(1073741824) = -268435456 (overflow)
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 12
 *   Rating: 3
 */
int ezThreeFourths(int x) {
  int xtimes3 = x + x + x;
  int neg = !!(xtimes3 & (1 << 31));        // neg = 1 if x < 0; 0 otherwise
  xtimes3 = xtimes3 + ((neg << 1) + neg);   // if neg, pad last 2 bits w/ 1s
  return ((xtimes3) >> 2) ;
}
/* 
 * tc2sm - Convert from two's complement to sign-magnitude 
 *   where the MSB is the sign bit
 *   You can assume that x > TMin
 *   Example: tc2sm(-5) = 0x80000005.
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 15
 *   Rating: 4
 */
int tc2sm(int x) {
  int sign_mask = 1 << 31;
  int neg_mask = (x & sign_mask) >> 31;
  // if x > 0, return x; else, XOR x with ~sign_mask, add 1
  int result = (neg_mask & ((x ^ (~sign_mask)) + 1)) | ((~neg_mask) & x);
  return result;
}

/* 
 * float_neg - Return bit-level equivalent of expression -f for
 *   floating point argument f.
 *   Both the argument and result are passed as unsigned int's, but
 *   they are to be interpreted as the bit-level representations of
 *   single-precision floating point values.
 *   When argument is NaN, return argument.
 *   Legal ops: Any integer/unsigned operations incl. ||, &&. also if, while
 *   Max ops: 10
 *   Rating: 2
 */
 
unsigned float_neg(unsigned uf) {
  // PORTABLE version (works for all word size)
  // unsigned ufn = ~0;
  // ufn = ~(ufn >> 1) ^ uf;
  // return ufn;
  return (uf ^ (1 << 31));
}

/* 
 * float_i2f - Return bit-level equivalent of expression (float) x
 *   Result is returned as unsigned int, but
 *   it is to be interpreted as the bit-level representation of a
 *   single-precision floating point values.
 *   Legal ops: Any integer/unsigned operations incl. ||, &&. also if, while
 *   Max ops: 30
 *   Rating: 4
 */
unsigned float_i2f(int x) {
  int msb_mask = (1 << 31);
  // get the sign of x
  int sign = x & msb_mask;
  
  // use the "absolute value" of x for fraction and exponent calculation
  unsigned frac = (x < 0) ? -x : x;
  int bias = (x) ? 127 : 0;
  // start exponent at 32, counting backwards
  int exp = 32;
  
  // find the leftmost 1 in abs_x
  int msb = frac & msb_mask;
  while ((!msb) && exp) {
    exp--;
    frac <<= 1;
    msb = frac & msb_mask;
  }

  // round frac to the first 23 bits
  //  to round (the last 9 bits) [in faux lisp]:
  //    (if (equal last-8-bits 0)
  //        (progn
  //          "(since (at-halfway-mark)
  //                  (incf rightmost-9th-bit rightmost-10th-bit)))
  //        (progn
  //          "(if (equal rightmost-9th-bit 0)
  //               (unaffected first-23-bits)
  //               (since (past-halfway-mark) (incf first-23-bits)))"
  //          (incf rightmost-9th-bit)))
  if (!(frac & 0x7f))
    frac += ((frac & (0x1 << 8)) >> 1);
  else
    frac += (0x1 << 7);
  
  // if the rounding caused an overflow, leading bit == 0
  // if overflow shift frac left 1 (past the first 1)
  // else do nothing
  if (frac & msb_mask) {
    frac = frac << 1;
    exp--;
  }
  // add bias to exp
  exp += bias;
  
  // shift frac and exp to position
  exp = exp << 23;
  frac = frac >> 9;

  //printf("%x \t %x \t %x \t %i \t %x \n", x, sign, exp, (exp >> 23), frac);
  return (sign | exp | frac);
}
